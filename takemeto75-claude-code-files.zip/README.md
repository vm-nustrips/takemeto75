# TakeMeTo75 - Development Guide

> "Because life's too short for bad weather"

AI-powered travel booking platform that finds destinations with perfect 75°F weather.

**Live URL:** https://takemeto75.vercel.app
**GitHub:** https://github.com/vm-nustrips/takemeto75

---

## Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Vercel CLI (`npm install -g vercel`)
- Git

### Local Development

```bash
# Clone the repository
git clone https://github.com/vm-nustrips/takemeto75.git
cd takemeto75

# Install dependencies
npm install

# Create .env.local with API keys
cat > .env.local << 'EOF'
WEATHER_API_KEY=fb6c2fb1033e486d88041004252712
DUFFEL_API_TOKEN=duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI
ANTHROPIC_API_KEY=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
EOF

# Run development server
npm run dev
```

Open http://localhost:3000

---

## Deployment

### From Zip File

```bash
# Navigate to downloads and extract
cd ~/Downloads
rm -rf takemeto75
unzip takemeto75.zip -d takemeto75
cd takemeto75

# Install and deploy
npm install
vercel --prod
```

### Environment Variables (Vercel)

Set these in Vercel Dashboard → Settings → Environment Variables:

| Variable | Value |
|----------|-------|
| `WEATHER_API_KEY` | `fb6c2fb1033e486d88041004252712` |
| `DUFFEL_API_TOKEN` | `duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI` |
| `ANTHROPIC_API_KEY` | `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` |

Or via CLI:

```bash
echo "fb6c2fb1033e486d88041004252712" | vercel env add WEATHER_API_KEY production
echo "duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI" | vercel env add DUFFEL_API_TOKEN production
echo "sk-ant-api03-..." | vercel env add ANTHROPIC_API_KEY production
vercel --prod
```

### One-Command Deploy Script

Save this as `deploy.sh`:

```bash
#!/bin/bash
cd ~/Downloads/takemeto75

# Remove old env vars and re-add
vercel env rm WEATHER_API_KEY production -y 2>/dev/null
vercel env rm DUFFEL_API_TOKEN production -y 2>/dev/null
vercel env rm ANTHROPIC_API_KEY production -y 2>/dev/null

# Add environment variables
echo "fb6c2fb1033e486d88041004252712" | vercel env add WEATHER_API_KEY production
echo "duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI" | vercel env add DUFFEL_API_TOKEN production
echo "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" | vercel env add ANTHROPIC_API_KEY production

# Deploy
vercel --prod

echo "✅ Deployed to https://takemeto75.vercel.app"
```

Run: `chmod +x deploy.sh && ./deploy.sh`

---

## GitHub Workflow

### Push Changes

```bash
cd ~/Downloads/takemeto75
git add .
git commit -m "your commit message"
git push
```

### Force Push (Replace Entire Codebase)

```bash
git push --force
```

### Initial Setup (New Machine)

```bash
# Clone repo
git clone https://github.com/vm-nustrips/takemeto75.git
cd takemeto75

# Link to existing Vercel project
vercel link

# Pull environment variables
vercel env pull .env.local

# Run locally
npm install
npm run dev
```

---

## Project Structure

```
takemeto75/
├── app/
│   ├── page.tsx              # Main UI with all components
│   ├── layout.tsx            # Root layout with fonts
│   ├── globals.css           # Tailwind + custom CSS
│   └── api/
│       ├── destinations/     # Weather-filtered destinations
│       ├── package/          # Flight + hotel search
│       ├── summary/          # AI destination summaries
│       └── book/             # Booking creation
├── lib/
│   ├── types.ts              # TypeScript interfaces
│   ├── destinations.ts       # Destination database
│   ├── weather.ts            # WeatherAPI client
│   ├── duffel.ts             # Duffel API client
│   ├── claude-selector.ts    # AI tier optimization
│   └── utils.ts              # Utility functions
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── next.config.js
```

---

## Tier System

| Tier | Price Range | Cabin Class | Hotels | Logic |
|------|-------------|-------------|--------|-------|
| Base | $400-700 | Economy | 3★ | Best value (price + duration + stops) |
| Premium | $700-1,200 | Economy/Premium Economy | 4★ | Convenience - pay 30-40% more for nonstop |
| Luxe | $1,500-3,000+ | Business/Premium Economy | 5★ Luxury | Premium airlines only, best experience |

---

## Design System

### Colors (CSS Variables)
```css
--coral: #E86B4F
--coral-dark: #D15A40
--cream: #FDF8F3
--forest: #2D4739
--forest-light: #3D5A4A
--sand: #F5E6D3
```

### Typography
- **Display:** Archivo Black
- **Body:** DM Sans

### UI Elements
- Cards: 3px forest border, 6px 6px 0 box-shadow
- Buttons: 50px border-radius, uppercase, hover translate

---

## API Reference

### GET /api/destinations
Returns 6 destinations filtered by weather (75°F, ≤2 cloudy days)

### POST /api/package
```json
{
  "origin": "SFO",
  "destinationId": "cancun",
  "tier": "premium",
  "departureDate": "2025-01-10",
  "returnDate": "2025-01-13"
}
```

### POST /api/summary
```json
{
  "destinationId": "cancun",
  "origin": "SFO"
}
```

---

## Creating Zip for Distribution

```bash
cd ~/Downloads/takemeto75
rm -rf node_modules .next .vercel
cd ..
zip -r takemeto75.zip takemeto75 -x "*.git*"
```

---

## Troubleshooting

### Geolocation not working
Safari requires user gesture. The app falls back to SFO.

### Mock data showing instead of real flights
Check Vercel environment variables are set correctly.

### Old version still showing after deploy
Clear Vercel cache: `vercel --force`

### Duplicate Vercel projects
Delete extras in Vercel Dashboard → Settings → Delete Project

---

## Version History

- **v0.1** (Current): Baseline functional build
- **v0.3** (Planned): Tier-based cabin classes, 98 airports, distance scoring

---

## Support

For issues, check:
1. Environment variables are set in Vercel
2. API keys are valid
3. No duplicate Vercel projects
4. Using correct baseline (v0.1)
