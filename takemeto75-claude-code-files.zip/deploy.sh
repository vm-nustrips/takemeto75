#!/bin/bash

# TakeMeTo75 Deployment Script
# Usage: chmod +x deploy.sh && ./deploy.sh

set -e

echo "🌴 TakeMeTo75 Deployment"
echo "========================"

# Navigate to project
cd ~/Downloads/takemeto75 2>/dev/null || {
    echo "❌ Project not found at ~/Downloads/takemeto75"
    echo "   First extract the zip: unzip takemeto75.zip -d takemeto75"
    exit 1
}

# Check for package.json
if [ ! -f "package.json" ]; then
    echo "❌ Not in a valid project directory"
    exit 1
fi

echo "📦 Installing dependencies..."
npm install

echo ""
echo "🔧 Setting up Vercel environment variables..."

# Remove old env vars (ignore errors)
vercel env rm WEATHER_API_KEY production -y 2>/dev/null || true
vercel env rm DUFFEL_API_TOKEN production -y 2>/dev/null || true
vercel env rm ANTHROPIC_API_KEY production -y 2>/dev/null || true

# Add environment variables
echo "fb6c2fb1033e486d88041004252712" | vercel env add WEATHER_API_KEY production
echo "duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI" | vercel env add DUFFEL_API_TOKEN production
echo "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" | vercel env add ANTHROPIC_API_KEY production

echo ""
echo "🚀 Deploying to production..."
vercel --prod

echo ""
echo "============================================"
echo "✅ DEPLOYMENT COMPLETE!"
echo "============================================"
echo ""
echo "🌐 Live at: https://takemeto75.vercel.app"
echo ""
