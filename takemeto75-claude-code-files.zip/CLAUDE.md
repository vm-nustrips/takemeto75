# TakeMeTo75 - Claude Code Instructions

This file provides context for Claude Code when working on this project.

## Project Overview

TakeMeTo75 is an AI-powered travel booking platform that finds destinations with perfect 75°F weather for quick, convenient getaways. The core value proposition is "Because life's too short for bad weather" - prioritizing convenience and seamless user experience over just finding the cheapest options.

## Critical Rules

1. **v0.1 is the baseline** - Always use as starting point for any builds
2. **Don't break working features** - Make ONLY the changes requested
3. **Preserve design aesthetics** - Archivo Black font, coral/forest/cream palette, 3D box-shadows
4. **Output single zip** - Always name it `takemeto75.zip`
5. **Keep responses lean** - No unnecessary explanations

## Tech Stack

- Next.js 14 + TypeScript
- Tailwind CSS
- Vercel deployment
- APIs: WeatherAPI, Duffel (flights), Anthropic Claude (AI)

## Tier Logic (Important!)

- **Base ($400-700)**: Economy only. Best VALUE (price + duration + stops together)
- **Premium ($700-1,200)**: Economy OR Premium Economy. Prioritize CONVENIENCE - pay 30-40% more for nonstop
- **Luxe ($1,500-3,000+)**: Business class when available (premium airlines ONLY), fallback to premium economy

## Flight Selection Principles

This is about QUICK, CONVENIENT GETAWAYS:
- Nonstop destinations at TOP of lists
- Depart within 72 hours
- Round-trip enabled by default
- Default 3 nights with +/- toggle

## UI Requirements

- 6 destinations on homepage (above the fold)
- Weather filtering: exclude >2 fully cloudy days, upgrade cloudy→partly cloudy
- AI summaries: 3-4 lines max with timing hooks
- No scroll in modals - everything fits on screen
- Price ranges rounded to nearest $100

## Design System

```css
--coral: #E86B4F
--cream: #FDF8F3
--forest: #2D4739
--sand: #F5E6D3
```

Font: Archivo Black (display), DM Sans (body)

## Environment Variables

```
WEATHER_API_KEY=fb6c2fb1033e486d88041004252712
DUFFEL_API_TOKEN=duffel_test_Tn6YxdalAbm35Nn9diwofPBOq5UEY3jEgcKN-AmcHfI
ANTHROPIC_API_KEY=sk-ant-api03-eZKJWfpg-...
```

## Deploy Command

```bash
cd ~/Downloads && rm -rf takemeto75 && unzip takemeto75.zip -d takemeto75 && cd takemeto75 && npm install && vercel --prod
```

## File Structure

```
app/
  page.tsx           # Main UI
  api/destinations/  # Weather-filtered destinations
  api/package/       # Flight + hotel search
  api/summary/       # AI summaries
lib/
  destinations.ts    # 45+ destinations with highlights
  duffel.ts         # Flight API
  claude-selector.ts # AI tier optimization
```

## Branding

- Never mention "Claude" in UI - use "Our AI"
- Tagline: "Because life's too short for bad weather"

## GitHub

- Repo: vm-nustrips/takemeto75
- Push: `git add . && git commit -m "msg" && git push`

## Reference

Load `takemeto75.json` for complete project knowledge including all destinations, airports, tier configurations, and development history.
